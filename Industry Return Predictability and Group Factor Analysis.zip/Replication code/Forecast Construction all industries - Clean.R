#############################################
# ConstructForecastLongShort.R


r = 120
pHold = 60
h = c(1)
names(h) = c('Horizon01')

computeMultiPeriodReturn = function(r, h){
  rMulti = matrix(NA, length(r), 1)
  for (t in 1:(length(r)-(h-1))){
    rMulti[t] = mean(r[t:(t+(h-1))])
  }
  return(rMulti)
}

estimateEnetAicc = function(x, y, lb){
  tss = sum((y - mean(y))^2)
  fit = glmnet(x, y, alpha = 0.5, nlambda = 200, lower.limits = lb)
  b = coef(fit)
  r2 = matrix(0, length(fit$lambda), 1)
  aicc = matrix(0, length(fit$lambda), 1)


  for (j in 1:length(fit$lambda)){
    ej = y - cbind(matrix(1, length(y), 1), x) %*% b[, j]
    r2[j] = 1 - sum(ej^2)/tss
    aicc[j] = length(y) * log(sum(ej^2) / length(y)) +
      2 * fit$df[j] * length(y) / (length(y) - fit$df[j] - 1)
  }

  minIndex = which.min(aicc)
  lambda = fit$lambda[minIndex]

  b = b[, minIndex]
  r2 = r2[minIndex]
  result = list('lambda' = lambda,
                'b' = b,
                'r2' = r2,
                'minIndex' = minIndex)

  return(result)
}

computeR2os = function(actual, f1, f2, h){
  msfe1 = mean((actual - f1)^2)
  msfe2 = mean((actual - f2)^2)
  r2os = 100 * (1 - msfe2 / msfe1)

  d = (actual - f1)^2 - (actual - f2)^2

  f = d + (f1 - f2)^2

  fit = lm(f ~ 1)

  var = sandwich::NeweyWest(fit, lag = h, prewhite = FALSE)

  cw = fit$coefficients / sqrt(var)

  result = list('r2os' = r2os,
                'cw' = cw)

  return(result)
}

#############################################
library(openxlsx)
library(varhandle)
library(glmnet)
library(pls)
library(sandwich)
####################

# Industry excess return
dataReturn = read.xlsx('./Data/dataIndustryRx.xlsx')

dataReturn$date = as.Date(as.character(dataReturn$date), format = '%Y%m%d')

dataReturn[, -1] = 100 * dataReturn[, -1]

date = dataReturn[, 1]

# Anomaly returns
dataAnomaly = read.xlsx('./Data/dataLongShortMissing.xlsx')

dataAnomaly$date = as.Date(as.character(dataAnomaly$date), format = '%Y%m%d')

dataAnomaly[, -1] = 100 * dataAnomaly[, -1]

dataAnomalyMissing = dataAnomaly

p = length(date) - r

for (t in 1:nrow(dataAnomaly)) {
  if (sum(is.na(dataAnomaly[t, ])) > 0) {
    dataAnomaly[t, which(is.na(dataAnomaly[t, ]))] =
      apply(dataAnomaly[t, -1], 1, mean, na.rm = TRUE)
  }
}

nameAnomaly = names(dataAnomaly)[-1]

##########################################################
# Take care of preliminaries for out-of-sample forecasting
##########################################################

# Forecasting strategies
nameForecast = c('Ols',
                 'Enet',
                 'Combine',
                 'Cenet',
                 'Avg',
                 'Pc',
                 'Pls')

for (col in 2:ncol(dataReturn)) {
  y = as.matrix(dataReturn[, col])

  actual = matrix(NA, p, length(h))
  colnames(actual) = names(h)

  coefCenetAll = rep(list(matrix(NA, p, length(nameAnomaly))),
                     times = length(h))
  names(coefCenetAll) = names(h)
  
  forecastPm = matrix(NA, p, length(h))
  colnames(forecastPm) = names(h)

  forecastUniAll = rep(list(matrix(NA, p, length(nameAnomaly))),
                       times = length(h))
  names(forecastUniAll) = names(h)

  forecastAll = rep(list(matrix(NA, p, length(nameForecast))),
                    times = length(h))
  names(forecastAll) = names(h)

  for (i in 1:length(h)) {
    colnames(coefCenetAll[[i]]) = nameAnomaly

    colnames(forecastUniAll[[i]]) = nameAnomaly

    colnames(forecastAll[[i]]) = nameForecast
  }

  ######################################################
  # Compute out-of-sample industry excess return forecasts
  ######################################################

  # Iterate over out-of-sample periods
  for (s in 1:p) {
    cat(sprintf('%s\n', date[r + s]))

    sy = y[1:(r + (s - 1))]

    for (i in 1:length(h)) {
      siy = computeMultiPeriodReturn(sy, h[i])

      if (s > pHold) {

        if (s <= p - (h[i] - 1)) {

          actual[s, i] = mean(y[(r + s):(r + s + (h[i] - 1))])
        }

        forecastPm[s, i] = mean(siy, na.rm = TRUE)
      }

      sx = as.matrix(dataAnomaly[1:(r + (s - 1)), -1])

      siData = cbind(siy, sx)

      siData = na.omit(siData)

      siy = as.matrix(siData[, 1])

      six = as.matrix(siData[, -1])

      for (j in 1:ncol(six)) {
        sijFit = lm(siy[-1] ~ six[-nrow(six), j])

        forecastUniAll[[i]][s, j] =
          sum(c(1, sx[nrow(sx), j]) * sijFit$coefficients)
      }

      if (s > pHold) {
        siDataOls = data.frame(siy[-1],
                               six[-nrow(six), ])

        colnames(siDataOls) = c('MKT',
                                nameAnomaly)

        ldVar = attributes(alias(lm(MKT ~ ., data = siDataOls))$Complete)$dimnames[[1]]

        if (length(ldVar) > 0) {
          siOlsIndex = which(!(colnames(siDataOls)[-1] %in% ldVar))
        } else {
          siOlsIndex = 1:length(nameAnomaly)
        }

        siFit = lm(siy[-1] ~ six[-nrow(six), siOlsIndex])

        forecastAll[[i]][s, 'Ols'] =
          sum(c(1, sx[nrow(sx), siOlsIndex]) * siFit$coefficients)

        siResult = estimateEnetAicc(six[-nrow(six), ],
                                    siy[-1],
                                    lb = -Inf)

        forecastAll[[i]][s, 'Enet'] = sum(c(1, sx[nrow(sx), ]) * siResult$b)

        forecastAll[[i]][s, 'Combine'] = mean(forecastUniAll[[i]][s, ])

        siyGr = siy[-(1:r)]

        sixGr = forecastUniAll[[i]][1:((s - 1) - (h[i] - 1)), ]

        siResultGr = estimateEnetAicc(sixGr,
                                      siyGr,
                                      lb = 0)

        coefCenetAll[[i]][s, ] = siResultGr$b[-1]

        siCenetIndex = which(siResultGr$b[-1] != 0)

        if (length(siCenetIndex) > 0) {
          if (length(siCenetIndex) == 1) {
            forecastAll[[i]][s, 'Cenet'] =
              forecastUniAll[[i]][s, siCenetIndex]
          } else {
            forecastAll[[i]][s, 'Cenet'] =
              mean(forecastUniAll[[i]][s, siCenetIndex])
          }
        } else {
          forecastAll[[i]][s, 'Cenet'] = forecastPm[s, i]
        }

        sxMissing = as.matrix(dataAnomalyMissing[1:(r + (s - 1)), -1])

        sxAvg = apply(sxMissing, 1, mean, na.rm = TRUE)

        sixAvg = sxAvg[1:(r + (s - 1) - (h[i] - 1))]

        siFit = lm(siy[-1] ~ sixAvg[-length(sixAvg)])

        forecastAll[[i]][s, 'Avg'] =
          sum(c(1, sxAvg[length(sxAvg)]) * siFit$coefficients)

        sxTilde = scale(sx)

        sixTilde = sxTilde[1:(r + (s - 1) - (h[i] - 1)), ]

        siFitPc = pcr(siy[-1] ~ sixTilde[-nrow(sixTilde), ],
                      ncomp = 1,
                      scale = FALSE)

        forecastAll[[i]][s, 'Pc'] =
          predict(siFitPc,
                  ncomp = 1,
                  newdata = t(sxTilde[nrow(sxTilde), ]))

        siFitPls = plsr(siy[-1] ~ sixTilde[-nrow(sixTilde), ],
                        ncomp = 1,
                        scale = FALSE)

        forecastAll[[i]][s, 'Pls'] =
          predict(siFitPls,
                  ncomp = 1,
                  newdata = t(sxTilde[nrow(sxTilde), ]))
      }
    }
  }

  cat('\n')

  ########################################
  # Create data frames & save as CSV files
  ########################################

  date_eval = date[-(1:(r + pHold))]

  actual_eval = data.frame(date_eval,
                           actual[-(1:pHold), ])

  forecastPm_eval = data.frame(date_eval,
                               forecastPm[-(1:pHold), ])

  write.csv(actual_eval,
            paste0('./Forecast_Clean/actual_', colnames(dataReturn)[col], '.csv'),
            row.names = FALSE)

  write.csv(forecastPm_eval,
            paste0('./Forecast_Clean/forecastPm_', colnames(dataReturn)[col], '.csv'),
            row.names = FALSE)

  for (i in 1:length(h)) {
    iForecast_eval = data.frame(date_eval,
                                forecastAll[[i]][-(1:pHold), ])

    write.csv(iForecast_eval,
              paste0('./Forecast_Clean/forecastLongShort_', colnames(dataReturn)[col], '_', names(h)[i], '.csv'),
              row.names = FALSE)
  }
}
