function [ X_stack ] = Stack_HF_LF_m_superiods(X,m)
%--------------------------------------------------------------------------
% DESCRIPTION: Matlab function taking as an input a panel of data of dimensions 
% (M*T X N), corresponding to HF data observed M times in each LF period 
% t = 1, ...T. The number of HF subperiods 'M' is also an input.
% The function generates 'M' panels of dimension (T X N), corresponding to the 
% LF "stock sampled" panels of observations for each HF subperiod m = 1,..., M.
%--------------------------------------------------------------------------
% Date  : 31.03.2019
% Author: Mirco Rubin
% Email : mircorubin@gmail.com
% updated files can be found also on the author's website:
% Web   : https://sites.google.com/site/mircorubin/ 
%--------------------------------------------------------------------------
% INPUT
% X  = mtx (m*T X N)
%--------------------------------------------------------------------------
% OUTPUT
% X_stack = (T X N X m)
%--------------------------------------------------------------------------
T  = size(X,1)/m;
N  = size(X,2)  ;

X_stack  = zeros(T,N,m) ; 

% OLD ---------------------------------------------------------------------
% X1 = zeros(T,N) ;
% X2 = zeros(T,N) ;
% X3 = zeros(T,N) ;
% X4 = zeros(T,N) ;
%--------------------------------------------------------------------------

for t = 1:T
for m_ind = 1:m
    X_stack(t,:,m_ind) = X(m*(t-1)+m_ind,:);
end
% OLD ---------------------------------------------------------------------
%     X1(t,:) = X(m*(t-1)+1,:) ;
%     X2(t,:) = X(m*(t-1)+2,:) ;
%     X3(t,:) = X(m*(t-1)+3,:) ;
%     X4(t,:) = X(m*(t-1)+4,:) ;
%--------------------------------------------------------------------------
end

end