#############################################
# EvaluateForecast.R
#############################################
library(openxlsx)
library(varhandle)
library(glmnet)
library(pls)
library(sandwich)
###################################
# Load realized returns & forecasts
###################################

computeR2os = function(actual, f1, f2, h){
  
  msfe1 = mean((actual-f1)^2)
  msfe2 = mean((actual-f2)^2)
  r2os = 100*(1 - msfe2/msfe1)
  d = (actual - f1)^2 - (actual - f2)^2
  f = d + (f1 - f2)^2
  
  # Clark-West regression
  fit = lm(f ~ 1)
  
  # Robust variance
  var = NeweyWest(fit,
                  lag = h,
                  prewhite = FALSE)
  
  # Clark-West statistic
  cw = fit$coefficients/sqrt(var)
  
  result = list('r2os' = r2os,
                'cw' = cw)
  
  return(result)
  
}

# Industries
industries <- c("Food", "Beer", "Smoke", "Games", "Books", "Hshld", "Clths", "Hlth", "Chems", "Txtls", "Cnstr", "Steel", "FabPr", "ElcEq", "Autos", "Carry", "Mines", "Coal", "Oil", "Util", "Telcm", "Servs", "BusEq", "Paper", "Trans", "Whlsl", "Rtail", "Meals", "Fin", "Other")

for (industry in industries) {
  
  # Actual excess returns
  actual = read.csv(paste0('./Forecast_Clean/actual_', industry, '.csv'))
  actual$date_eval = as.Date(actual$date_eval)
  actual = actual[ , 1:2 ]
  
  # Benchmark forecast
  forecastPm = read.csv(paste0('./Forecast_Clean/forecastPm_', industry, '.csv'))
  forecastPm$date_eval = as.Date(forecastPm$date_eval)
  forecastPm = forecastPm[ , 1:2 ]
  
  # Forecasts based on anomaly returns
  forecastAll = read.csv(paste0('./Forecast_Clean/forecastLongShort_', industry, '_Horizon01.csv'))
  forecastAll$date_eval = as.Date(forecastAll$date_eval)
  
  # Forecasting strategies
  nameForecast = names(forecastAll)[ -1 ]
  
  # Storage matrix for out-of-sample results
  stat = matrix(NA, length(nameForecast), 2)
  rownames(stat) = nameForecast
  colnames(stat) = c('r2os', 'cw')
  
  # Iterate over forecasts
  for ( i in 1:length(nameForecast) ){
    
    # Collect realized value & forecasts
    iData = cbind(actual[ , 2 ],
                  forecastPm[ , 2 ],
                  forecastAll[ , i+1 ])
    
    # Evaluate forecasts
    iResult = computeR2os(actual = iData[ , 1 ],
                          f1 = iData[ , 2 ],
                          f2 = iData[ , 3 ],
                          h = 1)
    
    stat[ i ,  ] = c(iResult$r2os,
                     iResult$cw)
    
  }
  
  stat = as.table(round(stat, 2))
  
  # Save table for each industry
  write.csv(stat,
            paste0('./Table_Clean/tableOosStatLongShort', industry, 'Horizon01.csv'))
}
