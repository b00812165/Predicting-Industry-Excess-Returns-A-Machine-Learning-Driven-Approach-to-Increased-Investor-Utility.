function r_est = rest_ratio(x, r_max, type)
    % Function to estimate the number of factors using Eigenvalue Ratio (ER)
    % or Growth Ratio (GR) based on Ahn and Horenstein's method.
    % 
    % Parameters:
    % x      - Input matrix
    % r_max  - Maximum number of factors to consider (optional)
    % type   - Type of estimation: 'ER' (Eigenvalue Ratio) or 'GR' (Growth Ratio)
    %
    % Output:
    % r_est  - Estimated number of factors

    if nargin < 3
        type = 'ER'; % Default to Eigenvalue Ratio
    end

    % Dimensions
    d = size(x, 1); % Number of groups
    p = size(x, 2); % Number of predictors plus intercept

    % Calculate R matrix
    R = (x * x') / (d * p);

    % Perform Singular Value Decomposition on R
    [~, S, ~] = svd(R);
    eigen_vals = diag(S);

    % Sort eigenvalues in descending order
    eigen_vals = sort(eigen_vals, 'descend');

    % Determine r_max if not provided
    if nargin < 2 || isempty(r_max)
        V0 = mean(eigen_vals);
        r_max = sum(eigen_vals > V0);
    end

    % Ensure r_max is valid
    if r_max >= length(eigen_vals)
        r_max = length(eigen_vals) - 1;
    end

    % Eigenvalue Ratio (ER) Estimation
    if strcmp(type, 'ER')
        ratios = zeros(r_max, 1);
        for v = 1:r_max
            ratios(v) = eigen_vals(v) / eigen_vals(v + 1);
        end
        [~, r_est] = max(ratios);

    % Growth Ratio (GR) Estimation
    elseif strcmp(type, 'GR')
        gr = zeros(r_max, 1);
        for v = 1:r_max
            numerator = log(1 + eigen_vals(v) / sum(eigen_vals((v+1):end)));
            denominator = log(1 + eigen_vals(v + 1) / sum(eigen_vals((v+2):end)));
            gr(v) = numerator / denominator;
        end
        [~, r_est] = max(gr);
    else
        error('Unknown type. Use "ER" or "GR".');
    end

    % Enforce minimum r = 2
    if r_est == 1
       r_est = 2;
    end
end
