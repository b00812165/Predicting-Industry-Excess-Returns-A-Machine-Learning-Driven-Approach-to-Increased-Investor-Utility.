function [Fhat, Lhat, eigval, ssr, v_explained ] = PCA_BAING_2002(X,k)
%--------------------------------------------------------------------------
% DESCRIPTION: Matlab function estimating latent factors from one panel
% of observable data using PCA as in Bai and Ng (2002). The function produces
% also the quantities needed to compute the IC_p and PC_p selection criteria 
% of Bai and Ng (2002).
%--------------------------------------------------------------------------
% Date  : 31.03.2019
% Author: Mirco Rubin
% Email : mircorubin@gmail.com
% updated files can be found also on the author's website:
% Web   : https://sites.google.com/site/mircorubin/ 
%--------------------------------------------------------------------------
% INPUT
% X         : (T X N) matrix
%
% OUTPUT
% Fhat   : (T X k) matrix of Factors
% Lhat   : (N X k) matrix of factor loadings
% eigval : (N X 1) eigenvalues
% ssr    : scalar
%--------------------------------------------------------------------------
[T,N]   = size(X)            ;
%--------------------------------------------------------------------------
% Computes factors and loading in the less compuationally intensive way
%--------------------------------------------------------------------------
if k == 0
Fhat  = zeros(T,1);
Lhat  = zeros(N,1);

eigval_all   = eig(X*X')       ;
eigval       = 0               ;

ssr          = sum(eigval_all)/(N*T) ;
v_explained  = 0               ;

% e_mat =  X                     ; % matrix errors of factor model
%--------------------------------------------------------------------------    
else   
if  N < T  
    [V,D]     = eigs(X'*X ,N-1)  ; % computes ordered N-1 eigenvalues (1st is the largest) and relative eigenvalues
    
    vecD       = diag(D)        ;
    eigval     = vecD(1:k)      ;
    
    Lhat_temp = V(:,1:k)        ; % ( N X k )
    Fhat_temp = X*Lhat_temp     ; % ( T X k )
    
    eigval_all = eig(X*X')      ; % returns all eigenvalues
    
else  % (N >= T)
    [V,D]     = eigs(X*X', T-1)  ;  % computes ordered T-1 eigenvalues (1st is the largest) and relative eigenvalues
    
    vecD       = diag(D)        ;
    eigval     = vecD(1:k)      ;
    
    Fhat_temp = V(:,1:k)        ; % ( T X k )
    %Lhat_temp = X'*Fhat_temp    ; % ( N X k )    
    
    eigval_all = eig(X*X')      ; % returns all eigenvalues 
end
%--------------------------------------------------------------------------
% Normalize factor and eigenvalues so that Fhat'Fhat = I_{T} 
% (each factor has unit length)
%--------------------------------------------------------------------------
sfac = sqrt(mean(Fhat_temp.^2))     ;

Fhat = Fhat_temp*(diag(sfac.^(-1))) ; % divide each column by its standard deviation
Lhat = X'*Fhat/T                    ; % NOTE: Fhat'Fhat = T

% Fhat = (T^(-0.5))*Fhat ;
% Lhat = (T^(0.5) )*Lhat ;

ssr          = (sum(eigval_all) - sum(eigval))/(N*T) ;
v_explained  = (sum(eigval))/(sum(eigval_all)) ;
%--------------------------------------------------------------------------
end
end % (function)