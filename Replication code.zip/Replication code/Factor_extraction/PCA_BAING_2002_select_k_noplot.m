function [kICp_vec, k_PCp_vec] = PCA_BAING_2002_select_k_noplot(X_nest, kmax_nest, which)
%--------------------------------------------------------------------------
% INPUT
% X         : (T X N) matrix
% kmax_nest : scalar = 'k_max' of Bai and Ng (2002)  
%
% OUTPUT
%
%--------------------------------------------------------------------------
[T_nest, N_nest] = size(X_nest)         ;
C2_NT            = min([N_nest,T_nest]) ;

[~, ~, ~, s2_nest, ~] = PCA_BAING_2002(X_nest,kmax_nest) ;

for k_nest = 1:kmax_nest
    
    ssr_nest    = [] ;
    
    [~, ~, ~, ssr_nest, ~] = PCA_BAING_2002(X_nest,k_nest) ;
    
    % IC_p1 (p.203, Bai Ng 2002)
    ICp(k_nest,1) =  log(ssr_nest) + k_nest*((N_nest+T_nest)/(N_nest*T_nest))*log((N_nest*T_nest)/(N_nest+T_nest)) ;
    % IC_p1 (p.203, Bai Ng 2002)
    ICp(k_nest,2) =  log(ssr_nest) + k_nest*((N_nest+T_nest)/(N_nest*T_nest))*log(C2_NT);
    % IC_p3 (p.203, Bai Ng 2002)
    ICp(k_nest,3) =  log(ssr_nest) + k_nest*(log(C2_NT)/C2_NT ) ; 
    % PC_p1 (p.203, Bai Ng 2002)
    PCp(k_nest,1) =  ssr_nest + k_nest*s2_nest*((N_nest+T_nest)/(N_nest*T_nest))*log((N_nest*T_nest)/(N_nest+T_nest))   ;
    % PC_p1 (p.203, Bai Ng 2002)
    PCp(k_nest,2) =  ssr_nest + k_nest*s2_nest*((N_nest+T_nest)/(N_nest*T_nest))*log(C2_NT) ;
    % PC_p1 (p.203, Bai Ng 2002)
    PCp(k_nest,3) =  ssr_nest + k_nest*s2_nest*(log(C2_NT)/C2_NT ) ; 
end
%--------------------------------------------------------------------------
% Case k = 0
ssr_nest = sum(trace(X_nest*X_nest'))/(N_nest*T_nest)   ;
ICp(kmax_nest+1,1) = log(ssr_nest) ;
ICp(kmax_nest+1,2) = log(ssr_nest) ;
ICp(kmax_nest+1,3) = log(ssr_nest) ;

PCp(kmax_nest+1,1) = ssr_nest      ;
PCp(kmax_nest+1,2) = ssr_nest      ;
PCp(kmax_nest+1,3) = ssr_nest      ;
%--------------------------------------------------------------------------
% ICp
[ k1, ~ ] = find(ICp(:,1) == min(ICp(:,1))) ;
[ k2, ~ ] = find(ICp(:,2) == min(ICp(:,2))) ;
[ k3, ~ ] = find(ICp(:,3) == min(ICp(:,3))) ;

if k1 > kmax_nest; k1 = 0 ; end
if k2 > kmax_nest; k2 = 0 ; end
if k3 > kmax_nest; k3 = 0 ; end

kICp_vec = [k1,k2,k3] ;
%--------------------------------------------------------------------------
% PCp % not displayed in output
[ k4, ~ ] = find(PCp(:,1) == min(PCp(:,1))) ;
[ k5, ~ ] = find(PCp(:,2) == min(PCp(:,2))) ;
[ k6, ~ ] = find(PCp(:,3) == min(PCp(:,3))) ;

if k4 > kmax_nest; k4 = 0 ; end
if k5 > kmax_nest; k5 = 0 ; end
if k6 > kmax_nest; k6 = 0 ; end

k_PCp_vec = [k4,k5,k6] ;
kICp_vec = kICp_vec(which);
k_PCp_vec = k_PCp_vec(which);
end
% END OF NESTED FUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%