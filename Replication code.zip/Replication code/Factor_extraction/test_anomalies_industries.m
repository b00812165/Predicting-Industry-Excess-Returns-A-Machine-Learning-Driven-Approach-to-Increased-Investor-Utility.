clear;
clc;

load('factors_data.mat')
%% Anomalies data
% Convert to matrix
matrix = struct2cell(dataAnomaly);   % Convert structure to a cell array
X_anomalies = cell2mat(matrix);    % Convert cell array to a numeric matrix
X_anomalies = reshape(X_anomalies, [], numel(fieldnames(dataAnomaly)));
%% Industry returns
matrix = struct2cell(dataReturn);   % Convert structure to a cell array
Y_industries = cell2mat(matrix);    % Convert cell array to a numeric matrix
Y_industries = reshape(Y_industries, [], numel(fieldnames(dataReturn)));


alpha_test = 0.05 ;
c_test     = 0.95 ;
gamma      = 0.1 ;
AGGREGATION_FIRST = 1 ;

% choose k_1 and k_2 estimator
%k_1 = rest_ratio(X_anomalies,10,'GR');
%k_2 = rest_ratio(Y_industries,10,'GR');
k_1 = PCA_BAING_2002_select_k_noplot(X_anomalies(1:end-1,:), 20, 1);
k_2 = PCA_BAING_2002_select_k_noplot(Y_industries(1:end-1,:), 20, 1);
k_min = min([k_1,k_2]);
kChat_savef  =      1;
[can_corr_all,...
 cc_test_mat_summary,...
 cc_test_mat_all,... 
 eigvalues_vcovHstack,...
 corr_factors_LF,...
 FC_hat, FH_hat, FL_hat] = Estimation_nfac_and_factors_EMPIRICAL(X_anomalies(1:end-1,:), Y_industries(1:end-1,:), AGGREGATION_FIRST, k_1, k_2, '1',c_test, gamma, kChat_savef);



% Rolling estimates of factors:
pHold = 60;
r = 120;
p = size(Y_industries,1) - r;

for h = 1:p
 idx = 1:(r + h - 1);
 [~,...
  ~,...
  ~,... 
  ~,...
  ~,...
 FC_hat, FH_hat, FL_hat] = Estimation_nfac_and_factors_EMPIRICAL(X_anomalies(idx,:), Y_industries(idx,:), AGGREGATION_FIRST, k_1, k_2, '1',c_test, gamma, kChat_savef);
 common_factors(1:(r + h - 1),:,h) = FC_hat;

end

save('estimated_factors_baing.mat', "common_factors")

