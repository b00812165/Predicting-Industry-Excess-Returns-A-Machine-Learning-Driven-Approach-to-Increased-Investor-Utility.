function [can_corr_all,...
          cc_test_mat_summary,...
          cc_test_mat_all,...
          eigvalues_vcovHstack,...
          corr_factors_LF,...
          FC_hat,...
          FH_hat,...
          FL_hat] = Estimation_nfac_and_factors_EMPIRICAL(X, Y, aggregtion_first_indicator,...
                                                          k_1, k_2,...
                                                          cf_est_type, c_test, gamma,...
                                                          kChat_savef)
%--------------------------------------------------------------------------
% DESCRIPTION: Matlab function performing:
%  - the estimation of the number of common and group-specific factors.
%  - the estimation of the common and group-specific factors.
%  The inputs are two panels of data observed at two different frequencies.
%--------------------------------------------------------------------------
% Date  : 31.03.2019
% Author: Mirco Rubin
% Email : mircorubin@gmail.com
% updated files can be found also on the author's website:
% Web   : https://sites.google.com/site/mircorubin/ 
%--------------------------------------------------------------------------
% INPUT
% X           : (T_HF X N_HF) matrix
% Y           : (T_LF X N_LF) matrix
% aggregtion_first_indicator  : scalar, with 2 possible values:
%                               1 --> aggregation prior to PCA on HF data
%                               0 --> PCA prior to aggregation on HF data
% k1          : scalar = kC_hat + kH_hat (estimated outside this function) 
% k2          : scalar = kC_hat + kL_hat (estimated outside this function) 
% cf_est_type : common factor estimation type ('1','2','3')
% c_test      : scalar = 'c' constant in quantile for test of n. of common factors
% gamma       : scalar = 'gamma' constant in quantile for test of n. of common factors
% kChat_savef : scalar = n. of common fators to consider (save) for output
%--------------------------------------------------------------------------
% OUTPUT
% cc_test_mat_summary : ...
% cc_test_mat_all     : ...
% FC_hat      : (4*T X k^c) estimated common (HF)factor
% FH_hat      : (4*T X k^H) estimated spec.   HF factor 
% FL_hat      : (T   X k^L) estimated spec.   LF factor 
%--------------------------------------------------------------------------
% Dimensions
[T_HF, N_HF] = size(X)    ; 
[T_LF, N_LF] = size(Y)    ;
N     = min([N_HF, N_LF]) ;
T     = T_LF              ;
N_1   = N_HF              ;
N_2   = N_LF              ;
m     = T_HF/T_LF         ; % number of high frequency sub-periods
k_min = min([k_1;k_2])    ; % minimum number of possible common factors
%--------------------------------------------------------------------------
% prepare empty OUTPUT TABLES
cc_test_mat_summary = zeros(1    ,3+k_min) ; 
cc_test_mat_all     = zeros(k_min,3      ) ;
%--------------------------------------------------------------------------
% Generate LF series form HF ones: X^L in notation of Online Appendix D.9
X_unstack  = Stack_HF_LF_m_superiods(X,m)  ;

% Flow sampling: aggregate (i.e. sum) within all m subperiods of each LF period 
X_agg = zeros(T,N_HF);
for ind_m = 1:m; 
X_agg = X_agg + X_unstack(:,:,ind_m); 
end
X_LF  = X_agg ; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if aggregtion_first_indicator == 1 % Aggregation first
% Compute only eigenvectors of X*X'/(T*N), eigenvectors of this matrix are not used
% NOTE: numerically sometimes is safer to divide by N instead of T*N 
%       in order to avoid 'too small' numbers in the matrix for which 
%       the eigenvectors are computed. This does not change the value of the 
%       eigenvectors, but just that of the eigenvalues(not used here).

% save only first k_1 eigenvectors 
[eigvec_X,~] = eigs(X_LF*X_LF'/N_HF, k_1) ; 
% Rescale eigenvectors to have var-cov = I in-sample
eigvec_X     = sqrt(T)*eigvec_X           ; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif aggregtion_first_indicator == 0 % PCA first
% PCA on HF data:
[eigvec_X_HF,~]   = eigs(X*X'/N_HF,k_1);

eigvec_X_HF_unstack = Stack_HF_LF_m_superiods(eigvec_X_HF,m);
eigvec_X_HF_agg     = zeros(T_LF,k_1);
for ind_m = 1:m
     eigvec_X_HF_agg = eigvec_X_HF_agg + eigvec_X_HF_unstack(:,:,ind_m); 
end

% Rescale eigenvectors to have var-cov = I in-sample
eigvec_X = eigvec_X_HF_agg*(((eigvec_X_HF_agg'*eigvec_X_HF_agg)/T_LF)^(-0.5)) ; 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[eigvec_Y,~] = eigs(Y*Y'/N_LF, k_2)       ; % save only first k_2 eigenvectors 
% Rescale eigenvectors to have var-cov = I in-sample
eigvec_Y     = sqrt(T)*eigvec_Y           ; 
%--------------------------------------------------------------------------
% Rename variables to make notation consistent with paper
H1   = eigvec_X ; 
H2   = eigvec_Y ;
V11  = H1'*H1/T ; 
V12  = H1'*H2/T ;
V21  = V12'     ;
V22  = H2'*H2/T ;
%--------------------------------------------------------------------------
% Stacked PCs
Hstack      = [H1, H2]         ;
vcovHstack  = Hstack'*Hstack/T ; 
% Eigenvalues of var-cov of stacked PCs form two panels
% unsorted eigenvalues:
[~,eigvalues_vcovHstack_uns] = eigs(vcovHstack, k_1+k_2); 
% sorted eigenvalues to save:
eigvalues_vcovHstack = sort(diag(eigvalues_vcovHstack_uns),'descend'); 

% NOTE: when n. of eigenvalues to compute is = dimension of the squared matrix
%       then 'eigs' compute UNSORTED eigenvectors and the associated
%       eigenvectors.
%       --> Both eigenvalues and eigenvectors must be resorted 
%          (from largest to smallest eigenvalue)
%--------------------------------------------------------------------------
% Compute all canonical correlations
R                         = (V11\V12)*(V22\V21)                ;
[eigvR_uns, eigR_mat_uns] = eigs(R,k_min)                      ; 
% Sort eigenvalues (and eigenvectors) from largest to smallest
[eigR, index_eigen_sort]  = sort(diag(eigR_mat_uns),'descend') ;
eigvR                     = eigvR_uns(:,index_eigen_sort)      ; 
% eigvR contains the k_min squared canonic. correlations 
% sorted form the largest to the smallest

% Compute & save the k_min canonical correlations
can_corr_all = sqrt(eigR) ;    % sqrt of sorted canonical correlations
%--------------------------------------------------------------------------
tab_ind = 0 ;

% Output table: all cc tests 
for kc_temp = linspace(k_min,1,k_min)         
    % compute test statics for all possible positive numbers of the common factors,
    % that is from k^c = k_min, up to k^c = 1 
    % i.e. considers: kc_temp = k_min, k_min-1 ,..., 1 
    
    tab_ind     = tab_ind  + 1  ; % index for table  
    % number of specific factors
    k1s_temp    = k_1 - kc_temp ;
    k2s_temp    = k_2 - kc_temp ;
    
    % sum first k_c sqrt of canonical correlations: test statistic
    sum_cc_temp = sum(can_corr_all(1:kc_temp,1)); 
    
    % COMPUTE FACTORS -----------------------------------------------------
    % canonical directions
    switch cf_est_type
        case '1'
            W1_temp    = eigvR(:,1:kc_temp)    ;  
            %--------------------------------------------------------------
            FChat_temp = H1*W1_temp            ; % common factor 
            %--------------------------------------------------------------
        case '2'
            Rast     = (V22\V21)*(V11\V12)                                ;
            [eigvRast_uns,eigRast_mat_uns] = eigs(Rast,k_min)             ;
            [~, index_eigen_sort] = sort(diag(eigRast_mat_uns),'descend') ;
             eigvRast             = eigvRast_uns(:,index_eigen_sort)      ;                    
            W2_temp  = eigvRast(:,1:kc_temp)                              ; 
            %--------------------------------------------------------------
            FChat_temp = H2*W2_temp                                       ; 
            %--------------------------------------------------------------
        case '3'                                
            P_sum = H1*H1' + H2*H2';
            % computes all 'k_min' eigenvalues (and eigenvectors) of the TXT matrix 'P_sum'
            [fac_temp_uns, D_uns] = eigs(P_sum, k_min)               ; 
            [~, index_eigen_sort] = sort(diag(D_uns),'descend')      ; % sort eignevalues and eigenvectors
             fac_temp_sort        = fac_temp_uns(:,index_eigen_sort) ;
             
            fac_temp_sort = sqrt(T)*fac_temp_sort                    ;
            %--------------------------------------------------------------
            FChat_temp = fac_temp_sort(:,1:kc_temp) ; % estimated common factor
            %--------------------------------------------------------------
    end
    %----------------------------------------------------------------------    
    % Compute specific factors (if any) at LF
    % Spec. factors are computed frome residuals of regr. on comm. fcts.
    MFC_temp      = eye(T) - FChat_temp*((FChat_temp'*FChat_temp)\FChat_temp') ;
    Xi1           = MFC_temp*X_LF ;
    Xi2           = MFC_temp*Y    ;
    %----------------------------------------------------------------------        
    % Compute LF-spec. factors (if any), and stack them together with common factor
    if k1s_temp > 0
        [FHast_temp_uns, D_temp_uns] = eigs(Xi1*Xi1'/N_HF, k1s_temp)      ;
        [~, index_eigen_sort]        = sort(diag(D_temp_uns),'descend')   ;
        FHast_temp       = FHast_temp_uns(:,index_eigen_sort)             ;        
        FHast_temp       = sqrt(T)*FHast_temp                             ;
        F1_temp          = [FChat_temp FHast_temp]                        ;
        MF1_temp         = eye(T) - F1_temp*((F1_temp'*F1_temp)\F1_temp') ;
        res_1_temp       = MF1_temp*X_LF                                  ;              
    else % NO HF spec. factor
        F1_temp          = FChat_temp                                     ;
        res_1_temp       = Xi1                                            ;
    end
    %----------------------------------------------------------------------
    % Compute LF-spec. factors (if any), and stack them together with common factor
    if k2s_temp > 0
        [FLast_temp_uns, D_temp_uns ] = eigs(Xi2*Xi2'/N_LF, k2s_temp)     ;
        [~, index_eigen_sort]         = sort(diag(D_temp_uns),'descend')  ;
        FLast_temp      = FLast_temp_uns(:,index_eigen_sort)             ;        
        FLast_temp       = sqrt(T)*FLast_temp                             ;
        F2_temp          = [FChat_temp FLast_temp]                        ;
        MF2_temp         = eye(T) - F2_temp*((F2_temp'*F2_temp)\F2_temp') ;
        res_2_temp       = MF2_temp*Y                                     ;
    else % NO LF spec. factor
        F2_temp          = FChat_temp                                     ;
        res_2_temp       = Xi2                                            ;
    end
    %----------------------------------------------------------------------      
    % LOADINGS MATRICES : 
    % used in TEST for n. of common factors, & to reconstruct HF estimates
    % of the COMMON and HF-specific factor by cross-sectional regressions
    L1hat       = (X_LF')*F1_temp/(F1_temp'*F1_temp) ; % dimensions: N_1 X (k^c + k^1_s) 
    L2hat       =    (Y')*F2_temp/(F2_temp'*F2_temp) ; % dimensions: N_2 X (k^c + k^2_s)
    %----------------------------------------------------------------------
    % Correlation matrix among ALL factors estimated at low frequency
    
    % Change sign of factors such that majority of loadings are positive: 
    % just computaiton of correlaiton matrix
    % NOTE: sign of saved (output) factors are not changed so that they can
    %       be changed in the main code
    if kc_temp == kChat_savef
        if k1s_temp > 0 && k2s_temp > 0
            F1_temp_newsign = F1_temp                                     ;
            [~,c_sign] = find(quantile(L1hat,0.5) < 0)                    ; 
            if isempty(c_sign) == 0
                F1_temp_newsign(:,c_sign) = - F1_temp_newsign(:,c_sign)   ;
            end    
            %---------
            F2_temp_newsign = F2_temp                                     ;
            [~,c_sign] = find(quantile(L2hat,0.5) < 0)                    ; 
            if isempty(c_sign) == 0
                F2_temp_newsign(:,c_sign) = - F2_temp_newsign(:,c_sign)   ;
            end
            %---------
            % save factors with new signs:
            all_est_factorsLF = [F1_temp_newsign, F2_temp_newsign(:,(kc_temp+1):(kc_temp+k2s_temp))]    ;
            % all_est_factorsLF = [FChat_temp, FHast_temp, FLast_temp] ;
        %------------------------------------------------------------------
        elseif  k1s_temp > 0 && k2s_temp == 0
            F1_temp_newsign = F1_temp                                     ;
            [~,c_sign] = find(quantile(L1hat,0.5) < 0)                    ; 
            if isempty(c_sign) == 0
                F1_temp_newsign(:,c_sign) = - F1_temp_newsign(:,c_sign)   ;
            end  
            % save factors with new signs:
            all_est_factorsLF = F1_temp_newsign                           ;
        %------------------------------------------------------------------
        elseif  k1s_temp == 0 && k2s_temp > 0
            F1_temp_newsign = F1_temp                                     ;
            [~,c_sign] = find(quantile(L1hat,0.5) < 0)                    ; 
            if isempty(c_sign) == 0
                F1_temp_newsign(:,c_sign) = - F1_temp_newsign(:,c_sign)   ;
            end    
            %--------------------------------------------------------------
            F2_temp_newsign = F2_temp                                     ;
            [~,c_sign] = find(quantile(L2hat,0.5) < 0)                    ; 
            if isempty(c_sign) == 0
                F2_temp_newsign(:,c_sign) = - F2_temp_newsign(:,c_sign)   ;
            end
            % save factors with new signs:
            all_est_factorsLF = [F1_temp_newsign, F2_temp_newsign(:,(kc_temp+1):(kc_temp+k2s_temp))]    ;
        %------------------------------------------------------------------
        elseif  k1s_temp == 0 && k2s_temp == 0
            F1_temp_newsign = F1_temp                                     ;
            [~,c_sign] = find(quantile(L1hat,0.5) < 0)                    ; 
            if isempty(c_sign) == 0
                F1_temp_newsign(:,c_sign) = - F1_temp_newsign(:,c_sign)   ;
            end    
            % save factors with new signs:
            all_est_factorsLF = F1_temp_newsign                           ;
        %------------------------------------------------------------------
        end 
    %----------------------------------------------------------------------
    % Correlation matirx between facotrs estimated at LF
    corr_factors_LF   = corr(all_est_factorsLF)                           ;
    end
    %----------------------------------------------------------------------
    % SAVE FACTORS FOR OUTPUT
    % reconstruct HF version of the COMMON and HF-specific factors 
    % (signs are not changed for output)
    F1_out_HF   = X*L1hat/(L1hat'*L1hat)     ; 
    F2_out_LF   = F2_temp                    ;
       
    if kc_temp == kChat_savef
        %------------------------------------------------------------------
        if kChat_savef == 0         % NO common factor
            FC_hat = zeros(m*T,1) ;
            FH_hat = zscore(H1)   ; % stdandardize output(saved) factor to have 0 mean & variance 1
            FL_hat = zscore(H2)   ; % stdandardize output(saved) factor to have 0 mean & variance 1
        %------------------------------------------------------------------    
        elseif kChat_savef == k_min % ALL common factors
            FC_hat = zscore(F1_out_HF) ;
            FH_hat = zeros(m*T,1)      ;
            FL_hat = zeros(T,1)        ;
        %------------------------------------------------------------------    
        else                       % some common and some specific factors
            FC_hat = zscore(F1_out_HF(:,1:kChat_savef))       ; % stdandardize output(saved) factor to have 0 mean & variance 1
            FH_hat = zscore(F1_out_HF(:,(kChat_savef+1):k_1)) ; % stdandardize output(saved) factor to have 0 mean & variance 1
            FL_hat = zscore(F2_out_LF(:,(kChat_savef+1):k_2)) ; % stdandardize output(saved) factor to have 0 mean & variance 1
        end
        %------------------------------------------------------------------
    end
    % Compute covariance matrix among all residuals stacked (both panel 1 and panel 2)
    Gamma_hat_all   = cov([res_1_temp res_2_temp]);
    %----------------------------------------------------------------------
    % Trim covariance matrix: all covariances corresponding to an absolute
    % value of correlation < 0.10 are set to 0.
    Gamma_hat_all_corr = corr([res_1_temp res_2_temp]);
    [r,c] = find(abs(Gamma_hat_all_corr) < 0.10);
    for i=1:size(r,1)
        if r(i)~=c(i) % this avoids trimming the variances (main diagonal)
        Gamma_hat_all(r(i),c(i)) = 0 ; % set covariance to 0 if correlation < 0.10
        end
    end    
    %----------------------------------------------------------------------
    Gamma_hat_1_mat  = Gamma_hat_all(1:N_1,1:N_1)                        ;
    Gamma_hat_2_mat  = Gamma_hat_all((N_1+1):(N_1+N_2),(N_1+1):(N_1+N_2));
    Gamma_hat_12_mat = Gamma_hat_all(1:N_1,(N_1+1):(N_1+N_2))            ;

    Gamma_hat_1  = Gamma_hat_1_mat       ;
    Gamma_hat_2  = Gamma_hat_2_mat       ;
    Gamma_hat_12 = Gamma_hat_12_mat      ;
    L1L1inv      = inv(L1hat'*L1hat/N_1) ;
    L2L2inv      = inv(L2hat'*L2hat/N_2) ;
  
    Sigma_hat_u1  = (L1L1inv)*(L1hat'*Gamma_hat_1*L1hat/N_1)*(L1L1inv)            ;
    Sigma_hat_u2  = (L2L2inv)*(L2hat'*Gamma_hat_2*L2hat/N_2)*(L2L2inv)            ;
    Sigma_hat_u12 = (L1L1inv)*(L1hat'*Gamma_hat_12*L2hat/sqrt(N_1*N_2))*(L2L2inv) ;
    Sigma_hat_u21 = Sigma_hat_u12'                                                ;
    
    Sigma_hat_u1_cc  = Sigma_hat_u1(1:kc_temp, 1:kc_temp) ;
    Sigma_hat_u2_cc  = Sigma_hat_u2(1:kc_temp, 1:kc_temp) ;
    Sigma_hat_u12_cc = Sigma_hat_u12(1:kc_temp,1:kc_temp) ;
    Sigma_hat_u21_cc = Sigma_hat_u21(1:kc_temp,1:kc_temp) ;

    Sigma_U_hat  = (N_2/N_1)*Sigma_hat_u1_cc + Sigma_hat_u2_cc - sqrt(N_2/N_1)*(Sigma_hat_u12_cc + Sigma_hat_u21_cc) ;   

    %----------------------------------------------------------------------    
    % COMPUTE TEST STATISTIC for number of common factors

    stat_cc = N*sqrt(T)*( (0.5*trace(Sigma_U_hat*Sigma_U_hat))^(-0.5) )*...
              ( sum_cc_temp - kc_temp + (1/(2*N))*trace(Sigma_U_hat)  );
          
    %----------------------------------------------------------------------
    % FILL OUTPUT TABLE with test results for each possible n. of common factors (>1)
    
    % COLUMN 1: kc_temp = n. of common factor tested (all integers from k_min to 1) :
    %           null HP to be tested in each colun: H_0: \hat{k}^c = kc_temp
    % COLUMN 2: value of the test statistics for the test of the null: H_0: \hat{k}^c = kc_temp
    % COLUMN 3: value of the summ of the largest kc_temp canonical
    %           correlations used to compute the test statisitcs
    cc_test_mat_all(tab_ind,:) = [kc_temp, stat_cc, sum_cc_temp ] ;                              
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PERFORM TEST <=> estimate number of common factors

% find columns corresponding to all the values of kc_temp s.t. null
% hypothesis (H_0: \hat{k}^c = kc_temp) is NOT rejected
[r_ind_test,~] = find(cc_test_mat_all(:,2) >= -c_test*(N*sqrt(T))^(gamma) ) ;

% Find largest value of kc_temp s.t. null hypothesis (H_0: \hat{k}^c = kc_temp) is NOT rejected

% NOTE: "cc_test_mat_all" displays "kc_temp" sorted in descending order
% -->  take minimum row index associated to the row s.t. H_0 in not rejected
% <=>  Find largest value of kc_temp s.t. null hypothesis (H_0: \hat{k}^c = kc_temp) is NOT rejected
if isempty(r_ind_test) == 1
    kc_hat = 0 ;
else
    kc_hat = cc_test_mat_all(min(r_ind_test),1) ;
end

kH_hat = k_1 - kc_hat ; 
kL_hat = k_2 - kc_hat ;
%----------------------------------------------------------------------
% FILL OUTPUT TABLE with test results for each possible n. of common factors (>1)
    
% COLUMN 1: \hat{k}^c = estimated number of COMMON factors
% COLUMN 2: \hat{k}^H = estimated number of HF-specific
% COLUMN 3: \hat{k}^L = estimated number of LF-specific

% COLUMNS (3+1) to (3+k_min): values of all the test statistics for all the k_min the null hypotheses: 
% H_0: \hat{k}^c = k_min
% H_0: \hat{k}^c = k_min-1
% ...
% H_0: \hat{k}^c = 1

cc_test_mat_summary(1,1) = kc_hat ;
cc_test_mat_summary(1,2) = kH_hat ;
cc_test_mat_summary(1,3) = kL_hat ;

cc_test_mat_summary(1,4:(3+k_min)) = cc_test_mat_all(:,2)'  ;