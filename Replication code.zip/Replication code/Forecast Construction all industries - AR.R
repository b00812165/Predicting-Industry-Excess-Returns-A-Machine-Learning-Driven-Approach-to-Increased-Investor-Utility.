library(openxlsx)

# Load data
dataReturn = read.xlsx('./Data/dataIndustryRx.xlsx')
dataReturn$date = as.Date(as.character(dataReturn$date), format = '%Y%m%d')
dataReturn[, -1] = 100 * dataReturn[, -1]
date = dataReturn[, 1]

# Parameters
r = 120
pHold = 60
p = length(date) - r

# Iterate over each industry
for (col in 2:ncol(dataReturn)) {
  y = as.matrix(dataReturn[, col])
  
  # Initialize storage for forecasts
  forecastAr = matrix(NA, p, 1)
  colnames(forecastAr) = c('AR')
  
  # Iterate over out-of-sample periods
  for (s in 1:p) {
    cat(sprintf('%s\n', date[r + s]))
    
    sy = y[1:(r + (s - 1))]
    
    if (s > pHold) {
      fit = lm(sy[-1] ~ sy[-length(sy)])
      forecastAr[s, 1] = sum(c(1, sy[length(sy)]) * fit$coefficients)
    }
  }
  
  cat('\n')
  
  # Create data frame & save as CSV file
  date_eval = date[-(1:(r + pHold))]
  forecastAr_eval = data.frame(date_eval, forecastAr[-(1:pHold), ])
  write.csv(forecastAr_eval, paste0('./Forecast_AR(1)/forecastAr_', colnames(dataReturn)[col], '.csv'), row.names = FALSE)
}