rm(list=ls())
wd <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(wd)

project <- function(X, Fhat){
  nobs <- dim(X)[1]
  Proj <- diag(nobs) - Fhat%*%pracma::inv(t(Fhat)%*%Fhat)%*%t(Fhat)
  Xout <- Proj%*%X
  return(Xout)
}


test_beta = function(y, X, level = 0.1){
  require(matrixStats)
  require(glmnet)
  require(MASS)
  
  ReverseColumns <- function(A){
    # Input: A = arbitrary matrix
    # Output: matrix with inversed order of columns
    return(A[, rev(1:dim(A)[2])])
  }
  ComputeLasso <- function(y, X, nbr.lambda=100){
    # Input: y = R^n
    #        X = R^(n x p)
    #        (nbr.lambda = number of grid points)
    # Output: lasso path:
    #         $lambda.grid = lambda grid used
    #         $estimator.grid = corresponding estimators
    # Details: 1. the lasso's objective function is
    #             |y-Xb|^2_2/n+lambda|b|_1
    #          2. the lambda sequence is increasing
    # definition of lambda grid
    # Note: Default grid of glmnet is NOT equidistant
    n <- length(y)
    lambda.max <- 2 * max(abs(t(X) %*% y)) / n  
    lambda.grid <- seq(0, lambda.max, by=lambda.max/nbr.lambda)
    lambda.grid <- lambda.grid[-1]
    
    # lasso fit with glmnet
    lasso.fit <- glmnet::glmnet(y=y, x=X, lambda=rev(lambda.grid/2), standardize=FALSE, 
                                standardize.response=FALSE, intercept=FALSE)
    
    return(list("lambda.grid" = lambda.grid, 
                "estimator.grid" = ReverseColumns(data.matrix(lasso.fit$beta))))
  }
  CriterionQuantiles <- function(y, X, level, estimator.grid, nbr.bootstraps=1000){
    # Input: y = R^n
    #        X = R^(n x p)
    #        level = vector of alpha levels
    #        estimator.grid = R^(p x length(lambda.grid)); each column is an estimator 
    #        (nbr.bootstraps = 1000)
    # Output: matrix of quantile(criterion.function) at the given alpha levels; 
    #         each row corresponds to a tuning parameter value in lambda.grid
    criterion.quantiles <- matrix(0, nrow=dim(estimator.grid)[2], ncol=length(level))
    residual.ext <- matrix(rep(y, dim(estimator.grid)[2]), nrow=dim(X)[1]) - X %*% estimator.grid
    residual.large <- matrix(rep(residual.ext, nbr.bootstraps), nrow=dim(residual.ext)[1])
    residual.randomized <- residual.large * (matrix(rnorm(dim(X)[1] * nbr.bootstraps), nrow=dim(X)[1]) 
                                             %x% matrix(rep(1, dim(estimator.grid)[2]), nrow=1))
    effective.noise.matrix <- t(X) %*% residual.randomized
    effective.noise <- 2 * matrixStats::colMaxs(abs(as.matrix(effective.noise.matrix))) / dim(X)[1]
    for(index.lambda in 1:dim(estimator.grid)[2]) {
      indexes <- seq(1, nbr.bootstraps*dim(estimator.grid)[2], by=dim(estimator.grid)[2]) + (index.lambda-1) 
      for(ll in 1:length(level))
        criterion.quantiles[index.lambda, ll] <- as.numeric(quantile(effective.noise[indexes], level[ll]))
    }
    return(as.matrix(criterion.quantiles))
  }
  QuantileEstimated <- function(y, X, level, nbr.lambda=100, nbr.bootstraps=1000, verbose=FALSE) {
    # Input:  y = R^n
    #         X = R^(n x p)
    #         level = target alpha levels
    #         (nbr.lambda = 1, 2, ...)
    #         (nbr.bootstraps = 1, 2, ..)
    #         (verbose = TRUE/FALSE)
    # Output: estimated quantile of effective noise 2|X^T epsilon|/n
    #         verbose == TRUE produces additional plots 
    lasso.fit <- ComputeLasso(y, X, nbr.lambda)
    lambda.grid <- lasso.fit$lambda.grid 
    estimator.grid <- lasso.fit$estimator.grid
    criterion.quantiles <- CriterionQuantiles(y              = y, 
                                              X              = X, 
                                              level          = level,
                                              estimator.grid = estimator.grid,
                                              nbr.bootstraps = nbr.bootstraps)
    selected.lambda <- rep(NA, length(level))
    for(ll in 1:length(level)) {
      selected.index <- length(lambda.grid)
      while ((selected.index > 1) && (criterion.quantiles[selected.index, ll] <= lambda.grid[selected.index]))
        selected.index <- selected.index - 1
      if(selected.index > 1)
        selected.index <- min(selected.index+1, length(lambda.grid))
      if((selected.index == 1) && (criterion.quantiles[1, ll] > lambda.grid[1]))
        selected.index <- 2
      selected.lambda[ll] <- criterion.quantiles[selected.index, ll]
    }
    if ((verbose == TRUE) && (length(level) == 1)) {
      print(paste0("Selected index/total indexes: ", selected.index, "/", length(lambda.grid)))
      dev.new()
      plot(lambda.grid, as.vector(criterion.quantiles), 
           ylim=c(0, max(max(lambda.grid),max(criterion.quantiles))), type="l")
      lines(lambda.grid, lambda.grid)
    }
    
    return(selected.lambda)
  }
  X <- scale(X, center = TRUE, scale = TRUE)
  
  # Adjust for Hill estimator:
  nobs <- length(y)
  # iota <- rep(1, nobs)
  # Proj <- diag(nobs) - iota %*% pracma::inv(t(iota) %*% iota) %*% t(iota)
  # y <- Proj %*% y
  # X <- Proj %*% X
  # Carry out test
  test.statistic <- 2 * max(abs(t(X) %*% y)) / dim(X)[1]
  nbr.lambda     <- 100
  nbr.bootstraps <- 1000
  crit.value <- QuantileEstimated(y              = y,
                                  X              = X,
                                  level          = 1-level,
                                  nbr.lambda     = nbr.lambda,
                                  nbr.bootstraps = nbr.bootstraps,
                                  verbose        = FALSE)
  reject <- as.numeric(test.statistic > crit.value)
  return(list(reject = reject, crit.value = crit.value, test.statistic = test.statistic,
              y = y, X = X, level = level))
}


find_pvalue <- function(yin, xin, i){
  level <- 1.0
  reject <- 1.0
  while (reject == 1){
    set.seed(1234)
    level <- level - 0.05
    print(paste0("computing for industry ", i, " at level ", level))
    if (level == 0.0)
      break
    fit <- test_beta(y = yin, X = xin, level = level)
    reject <- fit$reject
    
  }
  level <- level + 0.05
  reject <- 1.0
  while (reject == 1){
    set.seed(1234)
    level <- level - 0.001
    print(paste0("computing for industry ", i, " at level ", level))
    fit <- test_beta(y = yin, X = xin, level = level)
    reject <- fit$reject
  }
  return(level)
}

library(readxl)
industries <- read_excel("industries.xlsx", 
                         col_names = FALSE)


anomalies <- read_excel("anomalies.xlsx", 
                        col_names = FALSE)


library(R.matlab)
estimated_factors <- readMat("estimated_factors_baing.mat")
pvals <- matrix(NA, nrow = 30L, ncol = 5L)

Fhat <- estimated_factors$common.factors[,,456]
for (i in 1:30){
  y <- industries[,i] |> unlist() |> as.numeric()
  X <- anomalies |> as.matrix()
  newX <- project(X[-dim(X)[1],], Fhat[-dim(X)[1]])
  pvals[i,1] <- find_pvalue(y[-1], newX, i)
}

Fhat <- estimated_factors$anomaly.factors[,,456]
for (i in 1:30){
  y <- industries[,i] |> unlist() |> as.numeric()
  X <- anomalies |> as.matrix()
  newX <- project(X[-dim(X)[1],], Fhat[-dim(X)[1],])
  pvals[i,2] <- find_pvalue(y[-1], newX, i)
}

Fhat <- estimated_factors$industry.factors[,,456]
for (i in 1:30){
  y <- industries[,i] |> unlist() |> as.numeric()
  X <- anomalies |> as.matrix()
  newX <- project(X[-dim(X)[1],], Fhat[-dim(X)[1],])
  pvals[i,3] <- find_pvalue(y[-1], newX, i)
}

Fhat <- cbind(estimated_factors$common.factors[,,456], estimated_factors$anomaly.factors[,,456])
for (i in 1:30){
  y <- industries[,i] |> unlist() |> as.numeric()
  X <- anomalies |> as.matrix()
  newX <- project(X[-dim(X)[1],], Fhat[-dim(X)[1],])
  pvals[i,4] <- find_pvalue(y[-1], newX, i)
}

Fhat <- cbind(estimated_factors$common.factors[,,456], estimated_factors$industry.factors[,,456])
for (i in 1:30){
  y <- industries[,i] |> unlist() |> as.numeric()
  X <- anomalies |> as.matrix()
  newX <- project(X[-dim(X)[1],], Fhat[-dim(X)[1],])
  pvals[i,5] <- find_pvalue(y[-1], newX, i)
}
pvals_all <- pvals

save(pvals, file = "pvals-all.RData")
